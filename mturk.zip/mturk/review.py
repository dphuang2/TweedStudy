#!/usr/bin/env python
import MySQLdb
import csv
import inspect
from screen import screen
from boto.mturk.connection import MTurkConnection

def HIT_to_console(hit):
    print "Title: %s" % hit.Title
    print "HITId: %s" % hit.HITId
    print "  HITTypeId: %s" % hit.HITTypeId
    print "  HITGroupId: %s" % hit.HITGroupId
    print "  HITLayoutId: %s" % hit.HITLayoutId
    print "  CreationTime: %s" % hit.CreationTime
    print "  HITStatus: %s" % hit.HITStatus
    print "  Expiration: %s" % hit.Expiration
    print "  NumberOfAssignmentsAvailable: %s" % hit.NumberOfAssignmentsAvailable
    print "  NumberOfAssignmentsCompleted: %s" % hit.NumberOfAssignmentsCompleted
    print "  NumberOfAssignmentsPending: %s" % hit.NumberOfAssignmentsPending

# Credentials should be here
ACCESS_ID ='AKIAJAGMGSWH2FW3DJFQ'
SECRET_KEY = 'Z6NgnMoLKNuNpaz0+jE/CFYuyL44LbaVy+kENO6e'
HOST = 'mechanicalturk.sandbox.amazonaws.com'

# Make a connection to MTurk using your own credentials
mtc = MTurkConnection(aws_access_key_id=ACCESS_ID,
                      aws_secret_access_key=SECRET_KEY,
                      host=HOST)

# Make a connection to our MySQL database
db = MySQLdb.connect("engr-cpanel-mysql.engr.illinois.edu","twitterf_user","IIA@kT$7maLt","twitterf_tweet_store" )

# hit_ids = mtc.get_all_hits()
hit_ids = mtc.get_all_hits()

print "<<<<<<<<<------Processing Hits------>>>>>>>>>"
for hit in hit_ids:
    HIT_to_console(hit)

    assignments = mtc.get_assignments(hit.HITId)
    if not assignments:
        print "*No assignments for this HIT*"

    print "Processing %i assignments:" % len(assignments)
    for assignment in assignments:
        workerId = assignment.WorkerId
        print "  AssignmentId: %s" % assignment.AssignmentId
        print "  AssignmentStatus: %s" % assignment.AssignmentStatus
        print "  AutoApprovalTime: %s" % assignment.AutoApprovalTime
        print "  WorkerId: %s" % workerId

        print "Answers from the WorkerID: %s" % assignment.WorkerId
        for question_form_answer in assignment.answers[0]:
            for answer in question_form_answer.fields:
                print "Screening:----------------------->" 
                screen(db, workerId, answer, assignment.AssignmentStatus)

    print "-------------------------------------------------------------"
