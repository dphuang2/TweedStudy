#workerID should come from the AMT data -- their worker ID
#workerAnswer should come from the AMT data -- what they answered as the survey code

def screen(db, workerId, workerAnswer, status): 
    sql_workerExistsAndCompare = "SELECT code FROM `survey_responses_userinfo` WHERE `turkerID` = '" + workerId + "'"

    db.query(sql_workerExistsAndCompare)

    r=db.store_result()

    workerCode = r.fetch_row()

    # Exit from function if worker was not found
    if not workerCode:
        print "Worker was not found"
        return

    # if rows exist, check next condition, that the two match
    # check that the code they answered in the survey matches what we have
    if workerCode[0][0] == workerAnswer and status == "Submitted":
        print "workerCode equals workerAnswer!"
        # get user_id to not have to do joins in the future
        sql_getTwitterId = "SELECT user_id FROM `survey_responses_userinfo` WHERE `turkerID` = '" + workerId + "'"
        db.query(sql_getTwitterId)
        r=db.store_result()
        twitterId = r.fetch_row()
        if twitterId:
            twitterId = twitterId[0][0]

            # check number of clicks per page
            sql_numberClicks = "SELECT SUM( survey_responses.`0.001` ) , SUM( survey_responses.`0.251` ) , SUM( survey_responses.`0.501` ), SUM( survey_responses.`0.751` ), SUM( survey_responses.`1.001` ), SUM( survey_responses.`1` ) , SUM( survey_responses.`0.25` ),  SUM( survey_responses.`0.5` ),  SUM( survey_responses.`0` ) FROM `survey_responses` WHERE user_id = '" + str(twitterId) + "'"
            db.query(sql_numberClicks)
            r=db.store_result()
            numClicks = r.fetch_row()
            if numClicks:
                temp = 0
            for i in range(len(numClicks[0])):
                temp = temp + numClicks[0][i]

            # if temp > 12*2.5:
                # if verification question test


# Lookup table for verification questions
# Set verification question as third question on every page

# automically reject
# feedback :
# no record of survey
# not enough number of clicks
# did not interact with system as instructed
# you incorrectly answered too many of our verification questions (more than 15% wrong)
# 
# 85% - 16 questions right
